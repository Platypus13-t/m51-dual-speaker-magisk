#!/system/bin/sh
ui_print "M51 Dual Speaker Stereo Test v0.9"
ui_print "Routes built-in media to the WSA speaker and receiver."
ui_print "Receiver digital volume is 84 with stock EAR PA gain."
ui_print "Call routes and headphone-specific controls are unchanged."
set_perm_recursive "$MODPATH/system" 0 0 0755 0644

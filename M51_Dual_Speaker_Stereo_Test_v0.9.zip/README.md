# M51 Dual Speaker Stereo Test v0.9 — review/test build

Target: the connected SM-M515F (SM6150) running LineageOS 23.2 / Android 16.

## What changed

- Keeps the HAL backend tag `speaker`, so its existing usecase route names such as `low-latency-playback speaker` remain valid.
- Directs `SND_DEVICE_OUT_SPEAKER` to the combined WSA + RX interface while retaining the valid `speaker` HAL route suffix.
- Enables both WSA speaker and RX receiver media links in the eight active speaker-usecase paths (MultiMedia 1, 11, 5, 8, 4, 7, 10, 16). Built-in media should play through the bottom speaker and earpiece together.
- Uses receiver digital volume 84 and `EAR PA Gain=G_6_DB`, the level the user approved after an earpiece-only listening test.
- Does not alter call routes or headphone-specific control paths. Disable/uninstall the Magisk module and reboot to restore the previous setup.

## Evidence and limitations

The earlier v0.1 changed the backend tag to `speaker-and-receiver`, but provided only a path named `speaker-and-receiver`; Qualcomm HAL route names append the backend tag to each usecase path, so it would look for `low-latency-playback speaker-and-receiver`. The v0.2/v0.3 versions retained the stock WSA-only interface and added the RX mixer link before the stream PCM was opened. In v0.3, `rcv-media` is nested before its definition, which AOSP's parser skips. v0.4.1 set receiver mixer controls at runtime but still left the HAL's speaker interface WSA-only; it did not produce audible earpiece output.

This version carries the approved receiver level into the combined route. Acoustic output and headphone coexistence still require device listening checks. Roll back by disabling/uninstalling the module in Magisk and rebooting. No device files are overwritten outside the Magisk overlay.

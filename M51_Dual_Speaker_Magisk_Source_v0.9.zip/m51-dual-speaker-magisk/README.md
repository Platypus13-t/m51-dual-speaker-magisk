# Galaxy M51 Dual-Speaker Magisk Module

A reversible Magisk test module that routes built-in media to both the Galaxy M51 bottom speaker and receiver earpiece.

## Current tested build

- Version: **v0.9**
- Device: Samsung Galaxy M51 **SM-M515F** (SM6150)
- ROM used for the test: LineageOS 23.2 / Android 16
- Receiver level: digital volume 84 with the stock `EAR PA Gain=G_6_DB` setting
- Result: the phone owner confirmed media plays through both the bottom speaker and earpiece

## Install

Install `releases/M51_Dual_Speaker_Stereo_Test_v0.9.zip` from Magisk's Modules screen, then reboot. Use only on the listed model.

## Roll back

Disable or remove the `m51_dual_speaker_test` module in Magisk and reboot. This restores the phone's original vendor audio XML through Magisk's overlay mechanism.

## Verification limits

Built-in media stereo routing was confirmed by listening. Calls were not changed. The wired-headphone-specific routes were left as supplied by the phone, but a physical headphone test has not been done.

See [the investigation notes](docs/INVESTIGATION.md) for the version-by-version findings and [the module source](magisk-module/).
